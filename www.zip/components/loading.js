const Loading = () => {
  return (
    <div>
      <div className="loading-page">
        <p>Loading...</p>
      </div>
    </div>
  )
}
export default Loading;
