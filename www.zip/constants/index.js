export const URL_API = "https://fauzandev.my.id/api/";
export const BASE_URL = "https://fauzandev.my.id/";